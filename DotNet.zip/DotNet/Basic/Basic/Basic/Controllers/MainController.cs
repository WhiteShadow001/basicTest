﻿using Basic.Entity;
using Basic.Repository;
using Microsoft.AspNetCore.Mvc;

namespace Basic.Controllers
{
    [ApiController]
    [Route("[controller]")]

    public class MainController: ControllerBase
    {
        //yesh le chai repository(aile lai data rakheko thau) sanga conect garcga
        // java ma jastai ho, arko class ko method use gareko 
        private readonly BasicRepo repo = new BasicRepo();

        //IEnumerable le chai jasto type of pani list return garcha
        // yo method le chai taoai sanga bhaeko sabai data return garcha
        [HttpGet("getstudents")]
        public IEnumerable<Student> GetStudents()
        {
            var students = repo.printStudents();
            return students;
        }

        // yo method le chai student type ko data return garcha 
        // jasko id chai user le de a ko id sange milcha
        [HttpPost("getstudent")]
        public Student getStudent([FromBody] int id)
        {
            var student = repo.printStudent(id);
            return student;
        }
    }
}
