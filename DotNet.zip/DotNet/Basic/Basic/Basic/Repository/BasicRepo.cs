﻿using Basic.Entity;
using System.Linq;

namespace Basic.Repository
{
    // repository ma chia hamro main communication hucha
    public class BasicRepo
    {
        // yo chai aile lai data rakheko thau aile ko lagi
        // private ra readonly bhaneko chai bhai ra bata aru le edit garna na paos bhanera rakheko 
        private readonly List<Student> studList = new List<Student>()
        {
            new Student{Id=1, Name="Ram", Age=10, Roll=1},
            new Student{Id=2, Name="Shyam", Age=11, Roll=2}
        };

        // yesle chai tya controller ma call gareko thau ma sabai bhae bhar ko student ko data retrun garcha
        public IEnumerable<Student> printStudents()
        {
            return studList;
        }

        // yesle chai user le d a ko id sanga mile student ko data return garcha
        // yesma linq use gareko huna le dheri confuse na hunu 
        // tapai le for loop ra  if lagaera garda ne huncha comment ma de a ko jastai
        public Student printStudent(int id)
        {
            // for loop ra if use gareko 
            /*
            foreach (Student student in studList)
            {
                if(student.Id == id)
                {
                    return student;
                }
            }
            */
            return studList.Where(a => a.Id == id).SingleOrDefault();
        }
    }
}
