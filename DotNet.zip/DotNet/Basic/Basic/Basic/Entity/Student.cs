﻿namespace Basic.Entity
{

    // yesma chai student lai k k chaine ho tyo tyo data store huncha 
    // aba aru kei type ko data chaicha bhe yesma thapne store garna ko lagi
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public int Roll { get; set; }
    }
}
